function updateQualityInfo(){

  const quality =
    document.getElementById('qualityInput').value;

  document.getElementById('qualityInfo').innerHTML =
    `Compression Quality: ${quality}%`;
}

function compressImage(){

  const fileInput =
    document.getElementById('imageInput');

  const file = fileInput.files[0];

  if(!file){
    alert('Please select an image');
    return;
  }

  const width =
    parseInt(
      document.getElementById('widthInput').value
    );

  let quality =
    parseInt(
      document.getElementById('qualityInput').value
    ) / 100;

  const targetSize =
    parseInt(
      document.getElementById('targetSize').value
    );

  const reader = new FileReader();

  reader.onprogress = function(event){

    if(event.lengthComputable){

      const percent =
        Math.round(
          (event.loaded / event.total) * 100
        );

      document.getElementById('uploadText')
        .innerHTML =
        `Upload Progress: ${percent}%`;

      document.getElementById('uploadBar')
        .style.width =
        percent + '%';
    }
  };

  reader.readAsDataURL(file);

  reader.onload = function(event){

    const img = new Image();

    img.src = event.target.result;

    img.onload = function(){

      const canvas =
        document.createElement('canvas');

      const ctx =
        canvas.getContext('2d');

      const scale = width / img.width;

      canvas.width = width;

      canvas.height = img.height * scale;

      ctx.drawImage(
        img,
        0,
        0,
        canvas.width,
        canvas.height
      );

      function tryCompress(){

        canvas.toBlob(function(blob){

          const compressedURL =
            URL.createObjectURL(blob);

          const preview =
            document.getElementById('preview');

          preview.src = compressedURL;

          preview.style.display = 'block';

          const downloadBtn =
            document.getElementById('downloadBtn');

          downloadBtn.href = compressedURL;

          downloadBtn.download =
            'compressed-image.jpg';

          downloadBtn.style.display = 'block';

          const originalSize =
            (file.size / 1024).toFixed(2);

          const compressedSize =
            (blob.size / 1024).toFixed(2);

          const savedSize =
            (originalSize - compressedSize).toFixed(2);

          document.getElementById('sizeInfo').innerHTML = `
            Original Size: ${originalSize} KB <br>
            Compressed Size: ${compressedSize} KB <br>
            Saved: ${savedSize} KB <br>
            Target Size: ${targetSize} KB
          `;

          if(blob.size / 1024 > targetSize && quality > 0.1){

            quality -= 0.05;

            tryCompress();
          }

          downloadBtn.onclick = function(e){

  e.preventDefault();

  let progress = 0;

  const interval = setInterval(function(){

    progress += 10;

    document.getElementById('downloadText')
      .innerHTML =
      `Download Progress: ${progress}%`;

    document.getElementById('downloadBar')
      .style.width =
      progress + '%';

    if(progress >= 100){

      clearInterval(interval);

      const link =
        document.createElement('a');

      link.href = compressedURL;

      link.download =
        'compressed-image.jpg';

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);
    }

  }, 100);
};

        }, 'image/jpeg', quality);
      }

      tryCompress();
    };
  };
}